package com.example.base44rescue;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.view.*;
import android.widget.*;
import android.content.Intent;
import android.net.Uri;
import java.io.*;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    private WebView web;
    private EditText urlBox;
    private TextView status;
    private final LinkedHashMap<String, String> captured = new LinkedHashMap<>();
    private static final int CREATE_ZIP = 4102;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(12, 12, 12, 8);

        TextView heading = new TextView(this);
        heading.setText("Base44 Rescue — نسخه آزمایشی");
        heading.setTextSize(19);
        page.addView(heading);

        TextView warning = new TextView(this);
        warning.setText("فقط آدرس رسمی پروژه خودت را باز کن. ورود را خودت انجام بده؛ این ابزار رمز عبور را ذخیره یا ارسال نمی‌کند.");
        warning.setTextSize(13);
        page.addView(warning);

        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setHint("آدرس پروژه Base44");
        urlBox.setText("https://app.base44.com/");
        page.addView(urlBox);

        Button open = new Button(this);
        open.setText("باز کردن سایت");
        page.addView(open);

        LinearLayout actions = new LinearLayout(this);
        Button scan = new Button(this);
        scan.setText("استخراج کدهای در دسترس");
        Button export = new Button(this);
        export.setText("ذخیره ZIP");
        actions.addView(scan, new LinearLayout.LayoutParams(0, -2, 1));
        actions.addView(export, new LinearLayout.LayoutParams(0, -2, 1));
        page.addView(actions);

        status = new TextView(this);
        status.setText("هنوز فایلی استخراج نشده است.");
        page.addView(status);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String host = req.getUrl().getHost();
                if (host != null && (host.equals("base44.com") || host.endsWith(".base44.com"))) return false;
                status.setText("برای امنیت، فقط دامنه‌های Base44 داخل این ابزار باز می‌شوند.");
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "RescueBridge");
        page.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(page);
        open.setOnClickListener(v -> {
            String u = urlBox.getText().toString().trim();
            if (!u.startsWith("https://")) u = "https://" + u;
            Uri parsed = Uri.parse(u);
            String host = parsed.getHost();
            if (host == null || !(host.equals("base44.com") || host.endsWith(".base44.com"))) {
                status.setText("فقط آدرس رسمی با دامنه base44.com مجاز است.");
                return;
            }
            web.loadUrl(u);
        });
        scan.setOnClickListener(v -> scanCurrentPage());
        export.setOnClickListener(v -> {
            if (captured.isEmpty()) {
                status.setText("هنوز فایلی نداریم. ابتدا یک فایل کد را در Base44 باز و استخراج را بزن.");
            } else {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/zip");
                i.putExtra(Intent.EXTRA_TITLE, "Base44Rescue_backup.zip");
                startActivityForResult(i, CREATE_ZIP);
            }
        });
        web.loadUrl("https://app.base44.com/");
    }

    private void scanCurrentPage() {
        String js = "(function(){try{" +
          "let out=[];" +
          "if(window.monaco && monaco.editor && monaco.editor.getModels){" +
          " for(const m of monaco.editor.getModels()){let n='';try{n=m.uri.path.split('/').pop()||m.uri.toString().split('/').pop()}catch(e){};out.push({name:n||'monaco_file_'+(out.length+1)+'.txt',content:m.getValue()});}" +
          "}" +
          "if(!out.length && window.editor && typeof window.editor.getValue==='function'){out.push({name:'editor_current.txt',content:window.editor.getValue()});}" +
          "if(!out.length){document.querySelectorAll('.CodeMirror').forEach((e,i)=>{try{out.push({name:'codemirror_'+(i+1)+'.txt',content:e.CodeMirror?e.CodeMirror.getValue():e.innerText})}catch(x){}})}" +
          "if(!out.length){document.querySelectorAll('.cm-editor').forEach((e,i)=>{let c=e.querySelector('.cm-content');if(c)out.push({name:'codemirror6_'+(i+1)+'.txt',content:c.innerText})})}" +
          "if(!out.length){let a=document.querySelector('[data-testid*=code], [class*=editor] textarea, textarea[aria-label*=code i]');if(a && a.value)out.push({name:'visible_editor.txt',content:a.value});}" +
          "if(!out.length){let p=document.querySelector('.monaco-editor, pre code, [contenteditable=true]');if(p)out.push({name:'visible_code.txt',content:p.innerText||p.textContent||''});}" +
          "if(!out.length){RescueBridge.report('ویرایشگر قابل شناسایی نبود. فایل را باز کن و دوباره امتحان کن؛ ممکن است Base44 اجازه دسترسی DOM ندهد.');return;}" +
          "out.forEach(x=>RescueBridge.addFile(x.name,x.content));RescueBridge.report('تعداد موارد خوانده‌شده: '+out.length+'. این فقط کدهای در دسترس صفحه است، نه تضمین کل پروژه.');" +
          "}catch(e){RescueBridge.report('خطا: '+e.message)}})();";
        web.evaluateJavascript(js, null);
    }

    public class Bridge {
        @JavascriptInterface public void addFile(String name, String content) {
            runOnUiThread(() -> {
                String safe = name == null ? "file.txt" : name.replace("\\", "_").replace("../", "").replace("/", "_");
                if (safe.trim().isEmpty()) safe = "file.txt";
                captured.put(safe, content == null ? "" : content);
                status.setText("فایل‌های جمع‌آوری‌شده: " + captured.size() + " — " + safe);
            });
        }
        @JavascriptInterface public void report(String message) {
            runOnUiThread(() -> status.setText(message + " | فایل‌های ذخیره‌شده: " + captured.size()));
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_ZIP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                OutputStream raw = getContentResolver().openOutputStream(uri);
                ZipOutputStream zip = new ZipOutputStream(raw);
                for (Map.Entry<String,String> e : captured.entrySet()) {
                    zip.putNextEntry(new ZipEntry(e.getKey()));
                    zip.write(e.getValue().getBytes("UTF-8"));
                    zip.closeEntry();
                }
                zip.close();
                status.setText("ZIP ذخیره شد. تعداد فایل‌ها: " + captured.size());
            } catch (Exception ex) {
                status.setText("ذخیره ZIP ناموفق بود: " + ex.getMessage());
            }
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
